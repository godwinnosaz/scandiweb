<?php
  require_once('../app/bootstrap.php');
 //error_reporting(0);
  // Init Core Library
  $init = new Core;

